function Menu() {

    $(".main-menu-nav").on("click", ".menuBtn", function() {

        $(this).addClass("close");
        $(".main-menu-div").addClass("mobiel-menu"); /*.css({ "left": "0" });*/
        $(".body-overlay").css({ "display": "block", "z-index": "1" });
    });
    $(".main-menu-nav").on("click", ".body-overlay, .close-icon, .menuBtn.close", function() {

        $(".menuBtn").removeClass("close");
        $(".main-menu-div").removeClass("mobiel-menu");
        $(".body-overlay").css({ "display": "none", "z-index": "-1" });
    });

    /* adding span with arrow and .has-sub class */
    var menuID = $(".main-menu-nav");
    var downArrows = "<span class='down-arrow'></span>";
    var catchSubs = menuID.find('li ul');
    //$(".main-menu-nav li").has("ul").addClass('has-sub');
    catchSubs.parent().addClass('has-sub');
    catchSubs.parent().append(downArrows);

    /* submenu accordian */


    menuID.find('.down-arrow').on('click', function() {
        if ($(this).siblings('ul').hasClass('open')) {

            $(this).siblings('ul').slideUp(500, function() {
                jQuery(this).removeClass("open");
            });
            $(this).removeClass('submenu-opened');
        } else {

            $(this).siblings('ul').slideDown(500, function() {
                jQuery(this).addClass("open");
            });;
            $(this).addClass('submenu-opened');
        }
    });
    $(".main-menu-nav ul").unbind('mouseenter mouseleave');

    resizeFix = function() {
        var mediasize = 300;
        if ($(window).width() > mediasize) {

            menuID.on("mouseenter", ".has-sub", function() {

                $(this).addClass("hovered");
            }).on("mouseleave", ".has-sub", function() {
                $(this).removeClass("hovered");
            })
        }
        if ($(window).width() <= mediasize) {

            $(".main-menu-nav").on("mouseenter", ".has-sub", function() {
                $(".has-sub").removeClass("hovered");

            }).on("mouseleave", ".has-sub", function() {
                $(this).removeClass("hovered");
            })
        }
    };
    resizeFix();
    return $(window).on('resize', resizeFix);
}

// sticky header
// var header = jQuery(".header");
// var hheight = header.outerHeight();
// jQuery(window).scroll(function() {
//     var scroll = jQuery(window).scrollTop();
//     var device = jQuery(window).width();
//     console.log(hheight);
//     var coverUp = jQuery(".instantContact");
//     if (scroll > 200) {
//         header.removeClass('positioning').addClass("fixedUp");

//     } else {
//         header.removeClass("fixedUp").addClass('positioning');

//     }
//     if (scroll > 300) {
//         if (device > 991) {
//         header.removeClass('clearHeader').addClass("darkHeader");
//         coverUp.removeClass('noCoverUp').addClass("coverUp").css({ "margin-top": hheight + "px" });
//         coverUp.css({ "margin-top": hheight + "px" });
//         }

//     } else {
//         header.removeClass("darkHeader").addClass('clearHeader');
//         coverUp.removeClass('coverUp').addClass("noCoverUp").css({ "margin-top": 0 });
//         if (device > 991) {
//             coverUp.css({ "margin-top": 0 });
//         }

//     }
//     if (scroll > 950) {
//         header.removeClass('oldColor').addClass("diffColor");
//     } else {
//         header.removeClass("diffColor").addClass('oldColor');
//     }

//     var resizeFixed = function() {
//         var mediasize = 991;
//         if ($(window).width() > mediasize) {
//             header.removeClass("yes-mobile");
//             header.addClass("not-mobile");
//             coverUp.removeClass("yes-mobile");
//             coverUp.addClass("not-mobile");
//         }
//         if ($(window).width() <= mediasize) {
//             header.removeClass("not-mobile")
//             header.addClass("yes-mobile");
//             coverUp.removeClass("not-mobile");
//             coverUp.addClass("yes-mobile").css({ "margin-top": 0 });
//         }
//     };
//     resizeFixed();
//     return $(window).on('resize', resizeFixed);

// });
// $(".moveUp").click(function() {
//         $("html, body").animate({ scrollTop: 0 }, "slow");
//         return false;
//     });

// =============



jQuery(document).ready(function() {
    Menu();
    jQuery('.mainMenu ul li a').hover(function() {
        // $(this).addClass('subMenuAnchor');
        $(this).parents('ul').next().addClass('visibleUl');
        //  $(this).parents('ul').next().next().hover(function() {

        // }, function() {
        //     $(this).removeClass('visibleUl');

        // });
    }, function() {
        // $(this).removeClass('subMenuAnchor');
        $(this).parents('ul').next().hover(function() {
            // console.log("xxxx");
        }, function() {
            $(this).next().removeClass('visibleUl');
        })

    });
    jQuery('.mainMenu').hover(function() {

    }, function() {
        $(this).children('ul.visibleUl').removeClass('visibleUl');
    });

    //=================
    jQuery('.topSlider').slick({
        dots: true,
        arrows: false,
        infinite: true,
        speed: 1500,
        slidesToShow: 1,
        slidesToScroll: 1,
        autoplay: true,
        autoplaySpeed: 1500,


    });
    //=================
    jQuery('.saleSlider').slick({
        dots: false,
        arrows: true,
        infinite: true,
        speed: 300,
        slidesToShow: 5,
        slidesToScroll: 1,

        responsive: [{
                breakpoint: 1200,
                settings: {
                    slidesToShow: 4

                },
            },
            {
                breakpoint: 768,
                settings: {
                    slidesToShow: 3,
                    slidesToScroll: 1
                },
            },
            {
                breakpoint: 481,
                settings: {
                    slidesToShow: 2,
                    slidesToScroll: 1
                }
            },
             {
                breakpoint: 360,
                settings: {
                    slidesToShow: 1,
                    slidesToScroll: 1
                }
            }

        ]
    });
    //====================
     $('.proDetailSlider').slick({
  slidesToShow: 1,
  slidesToScroll: 1,
  arrows: false,
  dots:false,
  fade: true,
  asNavFor: '.proThumbnailSlider',

});
$('.proThumbnailSlider').slick({
  slidesToShow: 5,
  slidesToScroll: 1,
  asNavFor: '.proDetailSlider',
  dots: false,
  focusOnSelect: true,
   responsive: [{
                breakpoint: 992,
                settings: {
                    slidesToShow: 4

                },
            },
            {
                breakpoint: 481,
                settings: {
                    slidesToShow: 3

                },
            },
           

        ]
});
    


});